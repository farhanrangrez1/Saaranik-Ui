import React, { useState, useEffect } from "react";
import { Button, Form, Row, Col, Container } from "react-bootstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Base_Url from "../../ApiUrl/ApiUrl";

function AddNewJobsList() {
  const navigate = useNavigate();
  const [clients, setClients] = useState([]);
  const [jobData, setJobData] = useState({
    projectName: "",
    clientId: "",
    clientName: "",
    description: "",
    dueDate: "",
    priority: "Low",
  });

  // Fetch client list on mount
  useEffect(() => {
    const fetchClients = async () => {
      try {
        const res = await axios.get(`${Base_Url}/client/getAllClient`);
         console.log(res.data.data)
        setClients(res.data.data);
      } catch (err) {
        console.error("Error fetching clients:", err);
      }
    };
    fetchClients();
  }, []);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setJobData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle client selection to auto-fill client name
  const handleClientSelect = (e) => {
    const selectedClientId = e.target.value;
    const selectedClient = clients.find(c => c.id === parseInt(selectedClientId));
    setJobData((prev) => ({
      ...prev,
      clientId: selectedClientId,
      clientName: selectedClient ? selectedClient.name : "",
    }));
  };

  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      projectName: jobData.projectName,
      clientId: jobData.clientId,
      clientName: jobData.clientName,
      description: jobData.description,
      dueDate: jobData.dueDate,
      priority: jobData.priority,
    };

    try {
      await axios.post(`http://192.168.1.26:5008/api/job/createJob`, payload);
      toast.success("Job submitted successfully!");
      navigate("/jobAssignment");

      // Reset form
      setJobData({
        projectName: "",
        clientId: "",
        clientName: "",
        description: "",
        dueDate: "",
        priority: "",
      });
    } catch (error) {
      console.error("Submission Error:", error);
      toast.error("Failed to submit job.");
    }
  };

  return (
    <Container className="bg-white p-4 mt-4 rounded shadow-sm">
      <h5 className="fw-bold mb-4 text-start">Assign Jobs</h5>
      <Form onSubmit={handleSubmit}>
        {/* Project Name & Client */}
        <Row className="mb-3 text-start fw-semibold">
          <Col md={6}>
            <Form.Label>Project Name</Form.Label>
            <Form.Control
              type="text"
              name="projectName"
              value={jobData.projectName}
              onChange={handleChange}
              placeholder="Enter project name"
              required
            />
          </Col>
          <Col md={6}>
            <Form.Label>Designer </Form.Label>
            <Form.Select
              name="clientId"
              value={jobData.clientId}
              onChange={handleClientSelect}
              required
            >
              <option value="">Select Designer</option>
              {clients.map((client) => (
                <option key={client.id} value={client.id}>
                  {client.clientName}
                </option>
              ))}
            </Form.Select>
          </Col>
        </Row>

        {/* Job Description */}
        <Form.Group className="mb-3 text-start fw-semibold">
          <Form.Label>Job Description</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            name="description"
            value={jobData.description}
            onChange={handleChange}
            placeholder="Enter job description"
            required
          />
        </Form.Group>

        {/* Due Date & Priority */}
        <Row className="mb-4 text-start fw-semibold">
          <Col md={6}>
            <Form.Label>Due Date</Form.Label>
            <Form.Control
              type="date"
              name="dueDate"
              value={jobData.dueDate}
              onChange={handleChange}
              required
            />
          </Col>
          <Col md={6}>
            <Form.Label>Priority</Form.Label>
            <Form.Select name="priority"
              value={jobData.priority}
              onChange={handleChange}>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </Form.Select>
          </Col>
        </Row>

        {/* Buttons */}
        <div className="d-flex justify-content-end">
          <Button variant="light" className="me-2" onClick={() => navigate("/newJobsList")}>
            Back to List
          </Button>
          <Button id="All_btn" type="submit">
            Submit Job
          </Button>
        </div>
      </Form>
    </Container>
  );
}

export default AddNewJobsList;
